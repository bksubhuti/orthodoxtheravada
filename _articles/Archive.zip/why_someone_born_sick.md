---
layout: single
title: "Why is someone born sick with disease and dies early?"
date: 2026-06-14 08:00:00 -0400
categories: dhamma-talks
---

When people see a child born with a severe illness or someone who dies tragically young, they often ask, "Why did God allow this?" or "Why is the universe so unfair?" Traditional Theravāda Buddhism provides a very precise, mechanical answer: *Kamma* and its result (*vipāka*).

In the *Cūḷakammavibhaṅga Sutta*, the Buddha explicitly explains that beings are the owners of their kamma. If a person in a past life was in the habit of killing or harming beings—perhaps swatting insects without a second thought, or engaging in violence—that specific volitional action leaves a latent potential in the mental continuum. 

When that individual is reborn, that past unwholesome kamma can act as a destructive condition. It interferes with the production of material *kalāpas* during gestation and life. Harming others results in physical sickness and a fragile body. Killing beings cuts short the life faculty, resulting in a short lifespan for the perpetrator in a future life. It is not a punishment handed down by a divine judge. It is simply the natural, objective law of cause and effect executing perfectly.