---
layout: single
title: "What is a vīthi?"
date: 2026-05-18 08:00:00 -0400
categories: abhidhamma
---

When ordinary people talk about the mind, they usually think of it as a single, continuous entity. However, a single mind moment does not just pop into existence independently and hover there. In the Abhidhamma, we learn that consciousness arises in a highly structured, sequential series known as a cittavīthi. The Pāḷi word *vīthi* translates to "street" or "process." 

Just as a computer processor executes a strict series of micro-instructions to perform a single logical operation, the mind executes a highly specific sequence of mind moments to cognize an object. When a visible object strikes the eye door, for example, the mind does not simply "see" it instantly. A specific *vīthi* must run. The life continuum stream (*bhavaṅga*) is arrested, attention is adverted to the eye door, seeing consciousness arises, receiving consciousness follows, then investigating, determining, and finally the active *javana* moments where kamma is actually made. 

Because the refresh rate of the mind is unimaginably fast, it appears as a single, uninterrupted experience of "seeing." We think we are seeing, hearing, and thinking all at the same time. But the mind only does one thing at a time. It processes in serial order. Understanding the *vīthi* is crucial because it takes us out of the illusion of a solid self and shows us the mechanical, conditional nature of cognitive processing at the ultimate (*paramattha*) level.