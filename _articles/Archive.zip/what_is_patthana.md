---
layout: single
title: "What is paṭṭhāna?"
date: 2026-05-27 08:00:00 -0400
categories: abhidhamma
---

The *Paṭṭhāna* is the seventh and final book of the Abhidhamma Piṭaka, and it is arguably the most complex. It deals with the 24 conditional relations (*paccaya*). If the rest of the Abhidhamma defines the individual parts of reality—like the components on a digital circuit board—the *Paṭṭhāna* describes exactly how all those components are wired together.

It is the ultimate relational database of cause and effect. It explains that nothing arises from a single cause. For example, a single moment of anger does not just happen because someone insulted you. It requires the object condition (*ārammaṇa paccaya*), the proximity condition (*samanantara paccaya*) of the previous mind moment passing away, the decisive support condition (*upanissaya paccaya*) of your past habitual tendencies, and many others. 

The *Paṭṭhāna* removes any lingering idea of a creator god or a random, chaotic universe. By breaking down the exact algorithmic rules of how physical and mental phenomena support, produce, and maintain one another, it shows that the universe runs on a strict, unbreakable code of conditionality. When you understand even a fraction of this matrix, you gain immense faith in the Buddha's omniscience.