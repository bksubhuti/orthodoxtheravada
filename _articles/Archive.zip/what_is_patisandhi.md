---
layout: single
title: "What is paṭisandhi?"
date: 2026-06-17 08:00:00 -0400
categories: abhidhamma
---

*Paṭisandhi* is the "relinking consciousness." It is the very first *citta* that arises in a newly conceived life. It acts as the bridge connecting the previous existence to the new one. 

When a dying person reaches their final mind moment (*cuti citta*), it passes away. Immediately—without any gap, intervening bardo, or transition period—the *paṭisandhi citta* arises in the new location. There is no soul that detaches from one body and flies to another. It is simply a causal continuity. 

Think of it like passing a variable from one computer function to another. The exact data of the old variable dictates the starting state of the new one, but the physical memory sectors are entirely different. The *paṭisandhi citta* takes the exact same object that the mind grabbed hold of at the moment of death. Once this relinking moment arises and falls away in a fraction of a millisecond, the mind drops into the *bhavaṅga* (the life continuum stream), and the mechanism of a new lifetime is officially up and running.