---
layout: single
title: "What is dependent origination?"
date: 2026-06-08 08:00:00 -0400
categories: dhamma-talks
---

Dependent Origination (*Paṭiccasamuppāda*) is the core algorithm of *saṃsāra*. It is the specific chain of twelve conditional links that explains exactly how suffering arises and how beings are kept trapped in the cycle of rebirth. 

It begins with Ignorance (*avijjā*). Because we do not truly perceive the Four Noble Truths at the pixelated, ultimate level, we engage in Volitional Formations (*saṅkhāra*)—we make kamma. This kamma conditions the Relinking Consciousness (*viññāṇa*) of the next life, which drops into a womb, bringing Mind and Matter (*nāma-rūpa*). This leads to the Six Sense Bases (*saḷāyatana*), which make Contact (*phassa*) with objects. Contact produces Feeling (*vedanā*). 

Because we enjoy or hate those feelings, Craving (*taṇhā*) arises. Craving intensifies into Clinging (*upādāna*), which generates a new process of Becoming (*bhava*). That becoming inevitably results in Birth (*jāti*), which guarantees Aging and Death (*jarāmaraṇa*). 

This is not a philosophical theory; it is a mechanical, step-by-step flowchart of causality. There is no soul pulling the levers, just natural laws operating. By developing wisdom and destroying Ignorance, the first domino is removed, the loop is broken, and the entire structure of dependent suffering collapses.