---
layout: single
title: "What is a kasiṇa?"
date: 2026-06-23 08:00:00 -0400
categories: meditation
---

A *kasiṇa* is a specific type of meditation object used in the practice of *samatha* (tranquility) meditation to attain the deep absorptions known as *jhāna*. The word implies "entirety" or "totality," because the meditator expands the concept of the object until it fills their entire mental field.

There are ten traditional *kasiṇas*: earth, water, fire, wind, blue, yellow, red, white, light, and space. For an earth *kasiṇa*, a meditator might prepare a round disk of smooth clay. They gaze at it, taking in its color and shape, and then close their eyes to recreate the exact image in their mind (the learning sign). 

Through intense, sustained concentration, the mind drops its hindrances. The image becomes purified, bright, and conceptually perfect (the counterpart sign). The purpose of gazing at a *kasiṇa* is not mystical; it is a highly technical method to unify the *citta* on a single object so that the beautiful mental factors (*sobhana cetasika*) can arise continuously without being interrupted by the static noise of greed, hatred, or restlessness.