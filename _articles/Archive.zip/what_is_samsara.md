---
layout: single
title: "What is saṃsāra?"
date: 2026-06-05 08:00:00 -0400
categories: dhamma-talks
---

*Saṃsāra* translates to "continuous movement" or "the endless wandering." It is the cycle of repeated birth, mundane existence, and dying again. To put it in programming terms, *saṃsāra* is an infinite `while` loop, and the vast majority of beings do not have the break statement required to exit it.

It is not a physical place. You cannot travel to the edge of *saṃsāra*. It is the process of the aggregates (khandhas) endlessly reproducing themselves due to ignorance and craving. The Buddha taught that the tears we have shed over countless past lives, crying over the loss of loved ones, are greater than the waters of the four great oceans. 

Many people today romanticize the idea of past lives and reincarnation. They think of it as a great adventure where they get to try out different roles. In traditional Theravāda Buddhism, *saṃsāra* is viewed with profound danger and urgency. As long as the causes for rebirth are present, we are guaranteed to face old age, sickness, and death repeatedly, often falling into lower, agonizing realms of existence. The entire purpose of the Buddha's teaching is to halt this process once and for all.