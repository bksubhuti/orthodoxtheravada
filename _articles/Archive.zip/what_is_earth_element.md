---
layout: single
title: "What is earth element?"
date: 2026-06-20 08:00:00 -0400
categories: abhidhamma
---

When the Abhidhamma speaks of the earth element (*pathavī dhātu*), it is not talking about physical dirt, soil, or rocks. "Earth" is a conventional label for a specific ultimate reality. 

In *paramattha dhamma*, the earth element is the quality of hardness, softness, roughness, smoothness, heaviness, or lightness. It is the fundamental characteristic of extension and spatial occupation. You cannot actually *see* the earth element with your eyes—your eyes only see color (*vaṇṇa*). You experience the earth element through the physical body sense door when you touch something.

This element is one of the four great essentials (*mahābhūta*). It is present in absolutely every material particle (*kalāpa*) in existence. Even in a beam of light or a drop of water, the earth element is present, acting as the foundation for the other elements. An ordinary, uneducated person perceives a solid physical object. An Abhidhamma meditator perceives merely the raw data of hardness and extension arising and passing away rapidly.