---
layout: single
title: "What is a citta?"
date: 2026-05-21 08:00:00 -0400
categories: abhidhamma
---

*Citta* is typically translated as consciousness or mind, but technically, it is the bare cognizing of an object. It is the central processor of our experience. However, a *citta* never arises alone. It is fundamentally impossible to have a bare *citta* sitting isolated in a vacuum. 

A *citta* always arises together with mental factors called *cetasikas*. If *citta* is the pure water, the *cetasikas* are the dry ingredients—like flour, sugar, and baking soda—that mix with it. The water affects the dry ingredients, and the dry ingredients color and shape the water. They are inseparable. They arise together, pass away together, and take the exact same object.

Many modern meditators search for a pure, original consciousness, thinking that *citta* is an eternal, unchanging background. This is not Theravāda Buddhism. A *citta* is a momentary phenomenon. It arises, performs its specific function of knowing the object, and completely vanishes, immediately followed by the next *citta*. It has a refresh rate far faster than any digital display. When we recognize that *citta* is just a rapidly arising and passing phenomenon conditioned by its *cetasikas*, we stop identifying it as "my mind" or "my soul."