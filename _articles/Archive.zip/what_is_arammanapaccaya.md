---
layout: single
title: "What is ārammaṇa paccaya?"
date: 2026-05-24 08:00:00 -0400
categories: abhidhamma
---

*Ārammaṇa paccaya* translates to "object condition." In the mechanics of the mind, there can be no consciousness without an object. A *citta* must know *something*. That "something" is the *ārammaṇa*.

Think of it like a computer function that requires input variables to execute. If there is no input, the function does not run. The object condition is the stimulus that provides the necessary target for the mind to arise. These objects can be visible forms, sounds, smells, tastes, tangible touches, or mental objects (dhamma objects). 

Even in deep sleep or deep states of meditation, the mind is not empty of an object; it is simply taking a very subtle object, often the exact same object that appeared at the very last moment of the previous life. Without *ārammaṇa paccaya*, the cognitive process (*vīthi*) has no track to run on. The object acts as a condition by pulling the consciousness toward it, much like a walking stick acts as a condition for an old man to stand up. It is an indispensable requirement for the arising of mental phenomena.